# typed: strict
# frozen_string_literal: true

require "extend/os/mac/missing_formula" if OS.mac?
