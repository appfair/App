# typed: strict
# frozen_string_literal: true

module Readall
  class << self
    def valid_casks?(*)
      true
    end
  end
end
