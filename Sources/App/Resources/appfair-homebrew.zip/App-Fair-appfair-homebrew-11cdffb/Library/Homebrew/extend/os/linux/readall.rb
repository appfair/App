# typed: true
# frozen_string_literal: true

module Readall
  class << self
    def valid_casks?(_casks, bottle_tag: nil)
      true
    end
  end
end
