# typed: strict
# frozen_string_literal: true

require "extend/os/linux/install" if OS.linux?
